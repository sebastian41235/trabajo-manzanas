const express = require('express');
const bodyparser = require('body-parser');
const mysql = require ('mysql2/promise');
const app = express();

//configurar middleware
app.use(bodyparser.urlencoded({ extended: true }));
app.use(bodyparser.json());
app.use(express.static(__dirname));
//creacion coneccion
const db = mysql.createPool({
    host: 'localhost',
    user: 'root',
    passwoard: '',
    database: 'manzana',
});
//crear usuarios
app.post('/crear',async (req,res)=>{
    const{Nombre,Tipo_documento,Documento}=req.body;
    try{
        //verificador de usuario
        const[indicador]=await db.query('SELECT * FROM usuario WHERE Documento = ? AND Tipo_documento = ?',[Documento, Tipo_documento])

   if(indicador.length>0){
    res.status(409).send(`
        <script>
            window.onload = function() {
                alert('Ya existe usuario');
                window.location.href  = 'http://127.0.0.1:5500/vistas/index.html'
            }
        </script>
        `)
   }
    else{    await db.query(`INSERT INTO usuario (Nombre ,Tipo_documento ,Documento) VALUES(?,?,?)`,
    [Nombre,Tipo_documento,Documento])
    res.status(201).send(`
    <script>
    window.onload = function(){
        alert('Datos guardados');
        window.location.href='http://127.0.0.1:5500/vistas/index.html';
    }
    </script>`);
}
}
    catch(error){
        console.error('Error al conectar las bases de datos: ',error);
        res.status(500).send(`
        <script>
        window.onload =function(){
            alert('Datos guardados');
            window.location.href='http://127.0.0.1:5500/vistas/registro.html';
        }
        
        </script>`)
    }
})
app.post('/Iniciar',async (req,res)=>{
    const{documento,tipo_documento}=req.body
    try{
    //verifique las credenciales
    const[indicador]=await db.query('SELECT * FROM usuario WHERE Documento = ? AND Tipo_documento = ?',
    [documento, tipo_documento])
    console.log(indicador)
    if(indicador.length>0){
        res.redirect(`/bienvenida?usuario=${indicador[0].Nombre}`)
    }
    else{
        res.status(401).send("usuario no encontrado")
    }
    }
    catch(error){
        console.error('error en el servidor sapo:',error)
        res.status(500).send(`
        <script>
        window.onload =function(){
            alert('Error en el servidor');
            window.location.href='http://127.0.0.1:5500/vistas/inicio.html';
        }
        
        </script>`)
    }
})
app.get('/bienvenida',(req,res)=>{
    res.sendFile('/Users/APRENDIZ.BOGDAFCGFFSD164.000/Desktop/pag/vistas/usuario.html')
})
app.listen(3000,() =>{
    console.log("servidor Node.js escuchando");
})
/*db.on((err)=>{
    if(err) {
        console.error('Error al conectar las bases de datos: '+err.stack);
        return;
    }
    console.log('conexion exitosa a la base de datos');
});*/
/*app.post('/crear',(req,res)=>{
const{Nombre,Tipo_documento,Documento}=req.body;
const insertarxd = `INSERT INTO usuario (Nombre ,Tipo_documento ,Documento) VALUES(?,?,?)`;
db.query(insertarxd,[Nombre, Tipo_documento, Documento], (err,result)=>{


    console.log('Datos insertados correctamente');
    res.status(201).send('OK '); 
    if (err){
        console.error('Error al insertar datos: '+ err.stack);
        res.status(500).send('Error interno del servidor');
        return;
    
    }
})

})*/


